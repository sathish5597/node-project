const jwt = require('jsonwebtoken');
require("dotenv").config()

function verifyToken(req,res,next){
 const token = req.headers['authorization']
 const JWT_Secret_KEY = process.env.JWT_Secret_KEY
 if(!token){
    return res.status(403).json({ error: 'No token provided' });
 }
 jwt.verify(token.split(' ')[1],JWT_Secret_KEY,(err,decoded)=>{
    console.log(token.split(' '),"splitted")
    if(err){
        console.log(err,"Error")
            if (err.name === 'TokenExpiredError') {
                return res.status(401).json({ error: 'Token has expired' });
            }
            return res.status(401).json({ error: 'Failed to authenticate token' });

        }
        req.user = decoded;
        next();
    
 })
}
module.exports = verifyToken