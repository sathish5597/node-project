// errorMiddleware.js

function errorHandler(err, req, res, next) {
    console.error('Error caught by error handling middleware:', err);
  
    // Handle specific errors
    if (err.name === 'ValidationError') {
      // Mongoose validation error
      return res.status(400).json({ error: err.message });
    } else if (err.name === 'MongoError' && err.code === 11000) {
      // Mongoose duplicate key error
      return res.status(409).json({ error: 'Duplicate entry', key: err.keyValue });
    } else {
      // Generic server error
      return res.status(500).json({ error: 'Internal server error' });
    }
  }
  
  module.exports = errorHandler;
  