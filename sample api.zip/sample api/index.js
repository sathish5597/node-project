const express = require('express')
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const userRoutes = require('./routes/user')
const {mongodb} = require('./config/db.config')
const errorHandler = require('./middlewears/err')
require('dotenv').config();

const PORT = process.env.PORT
const app = express();

 mongodb()
app.use(express.json())
app.use(errorHandler)

app.use('/user',userRoutes)



app.listen(PORT, () => {
    console.log(`App isrunnig on ${PORT} `)
})