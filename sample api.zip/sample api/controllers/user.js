
const userSchema = require("../models/user")
const bcrypt = require('bcrypt')
const crpyto = require('crypto')
const JWT = require('jsonwebtoken')
require('dotenv').config();
async function  login(req,res){
    try{
    const {username,password,role}= await  req.body
    const jwt = process.env.JWT_Secret_KEY
    const salt = await bcrypt.genSalt(10)
    const hashedpassword = await bcrypt.hash(password,salt)
    // const secret = crpyto.randomBytes(64).toString('hex')
    // console.log(secret,"Secret")
    const existingUser = await userSchema.findOne({username})
    if(existingUser){
       return  res.status(400).json("Username Already Exist")
    }
        const user = new userSchema({
            username,
            password: hashedpassword,
            role
        })

        await user.save()
        const token = JWT.sign({username:user.username,password:user.password,role:user.role},jwt,{expiresIn:"1h"})
        return  res.status(201).json({message:"User Created Succfully",token})


}
catch(err){
    console.log(err.name)
   return  res.json(err)
}

}

module.exports={
    login
}