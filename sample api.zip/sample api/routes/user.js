const express = require('express');
const router = express.Router()
const userController = require('../controllers/user')
const verifyToken = require('../middlewears/verifymiddleware')


router.post('/login',userController.login)
router.get('/verify',verifyToken,(req,res)=>{
    return res.json({ message: 'This is a protected route', user: req.user });
});

module.exports= router