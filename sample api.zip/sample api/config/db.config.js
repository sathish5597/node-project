const mongoose = require("mongoose")
require("dotenv").config();

const mongodb = ()=>{
    try{
        mongoose.connect(process.env.mongodbURI,{
          })
          console.log("Db is connected")
    }
    catch(err){
        console.log("Db is disconnected")
        process.exit(1)
    }
}

module.exports = {mongodb}