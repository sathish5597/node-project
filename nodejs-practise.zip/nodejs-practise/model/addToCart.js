const mongoose = require('mongoose')



const addToCartSchema = new mongoose.Schema({
id:Number,
productName:String,
productCategory:String,
amount:String

},{timestamps:true})

module.exports = mongoose.model('addToCart',addToCartSchema)
