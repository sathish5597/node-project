const express = require('express')
const cron = require('node-cron')
const mongoose = require('mongoose')
const {writeToPath} = require('fast-csv')
const addToCart = require('./model/addToCart')
const app = express();
require('dotenv').config({path:'config/.env'})


app.use(express.json())
cron.schedule("* * * * *",()=>{
    try{
        console.log("Cron is running every 1 minute")
    }
    catch(err){
        console.log(`Error is ${err.message}`)
    }
})
app.get('',async (req,res)=>{
    const {productName,productCategory} = req.query
    const query={}
    if(productName){
        query.productName = {$regex:productName,$options:"i"}
    }
    if(productCategory){
        query.productCategory = productCategory
    }

    const getAll = await addToCart.find(query)
    res.status(200).send(getAll)
})

app.get('/export',async(req,res)=>{
    try{
    const {productName,productCategory} = req.query
    const query={}
    if(productName){
        query.productName = {$regex:productName,$options:"i"}
    }
    if(productCategory){
        query.productCategory = productCategory
    }

    const getAll = await addToCart.find(query)
    const csvString = JSON.stringify(getAll)
   const downloadcsv =  writeToPath(csvString, { headers: true })
   .on('error', (err) => {
    console.error('Stream error:', err);
    res.status(500).send('Failed to export CSV');
  })
  .on('finish', () => {
    console.log('CSV export successful');
  });
   req.headers('Content-Type', 'text/csv')
   req.headers('Content-Disposition', 'attachment; filename=addToCart.csv')
   res.status(200).send(downloadcsv)
}
catch(err){
    res.status(400).send(err);
}

})

app.post('/AddtoCart',async (req,res)=>{
    const {productName,productCategory,amount} = req.body
    const saveToCart = new addToCart({productName,productCategory,amount})
    await saveToCart.save()
    console.log(req.body)
    res.status(200).send(saveToCart)
})
app.put('/UpdateCart/:id',async (req,res)=>{
    const {id} = req.params
    const {productName,productCategory,amount} = req.body
    const updateCart = await addToCart.findByIdAndUpdate(id,{productName,productCategory,amount})
    res.status(200).send(updateCart)
})

app.patch('/PatchCart/:id',async (req,res)=>{
    const {id} = req.params
    const {productName,productCategory,amount} = req.body
    const updateCart = await addToCart.findByIdAndUpdate(id,{productName,productCategory,amount})
    res.status(200).send(updateCart)
})
app.get('/CartValue',async (req,res)=>{
    const CartTotalValue = await addToCart.aggregate([
        {
        $group:{
            _id:null,
            total:{$sum:{$toDouble:"$amount"}}
        }
    }])
    res.status(200).send(CartTotalValue)

}
)

mongoose.connect("mongodb+srv://Satish:NETLR1ZmcDL8ELEO@satish.fhufmgo.mongodb.net/",{
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
.then(()=>{
    console.log("Database is connected")
}).catch((error)=>{
    console.log("Error in Database",error)
})
app.listen(process.env.PORT ,()=>{
    console.log(`Server Started${process.env.PORT}`)
})