const fs = require('fs')

const readalbeStream = fs.createReadStream('index.txt',{
    encoding:'utf8',
    highWaterMark:16
})

const writeableStream = fs.createWriteStream('output.txt')

readalbeStream.on('data',(chunk)=>{
    console.log("Received chunk",chunk)
    writeableStream.write(chunk)
})

readalbeStream.on('end',()=>{
    console.log("Finished Reading a File ")
    writeableStream.end()
})
readalbeStream.on('error',(err)=>{
    console.log("Error While Reading a File",err.message)
})
readalbeStream.on('finish',()=>{
    console.log("Finished")
})